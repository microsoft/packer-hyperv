$src = ".\core-config-mod\packer.config"
$dst = "$env:APPDATA\packer.config"

if( (Test-Path $src) -eq $false) {
	Write-Error "File $src doesn't exist."
	Break;
} 

$jsonSrc = Get-Content $src | Out-String | ConvertFrom-Json 
if ($jsonSrc.builders -eq $null) {
	Write-Error "File $src doesn't contain 'builders' section."
	Break;
}

# check whether config already exists
if(Test-Path $dst) { #add our builders if none
	$modified = $false
	$jsonDst = Get-Content $dst | Out-String | ConvertFrom-Json
	
	if ($jsonDst.builders -ne $null) { # check if our builders already exist
		$jsonSrc.builders.psobject.properties | foreach {
			$name = $_.Name
			$val = $_.Value
			
			$b = $jsonDst.builders.psobject.properties | ? {$_.Name -eq $name}
			if( $b -eq $null) {
				$jsonDst.builders | Add-Member @{$name = $val}
				$modified = $true
			}
		}
	}
	else { # just add our builders section
		$jsonDst | Add-Member @{"builders" = $jsonSrc.builders }
		$modified = $true
	}
	
	if ($jsonDst.provisioners -ne $null) { # check if our provisioners already exist
		$jsonSrc.provisioners.psobject.properties | foreach {
			$name = $_.Name
			$val = $_.Value
			
			$b = $jsonDst.provisioners.psobject.properties | ? {$_.Name -eq $name}
			if( $b -eq $null) {
				$jsonDst.provisioners | Add-Member @{$name = $val}
				$modified = $true
			}
		}
	}
	else { # just add our provisioners section
		$jsonDst | Add-Member @{"provisioners" = $jsonSrc.provisioners }
		$modified = $true
	}
	
	if ($modified){
		$jsonDst | ConvertTo-Json -depth 5 | Out-File $dst -encoding ASCII
	}
}
else { #just copy our file
	Copy-Item $src $env:APPDATA
}

$loc = Get-Location;
$envvars=[Environment]::GetEnvironmentVariable('Path', 'User');
if($envvars -ne $null -and $envvars.Split(";") -contains $loc){
	Break
}
else {
	$envvarsnew=[string]::Join(';',@($loc,$envvars));
	[Environment]::SetEnvironmentVariable('Path', $envvarsnew, 'User')
}


